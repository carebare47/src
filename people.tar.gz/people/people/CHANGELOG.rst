^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package people
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.9 (2015-09-01)
------------------

1.0.8 (2014-12-10)
------------------
* moved social_navigation_layers from metapackage
* Contributors: Dan Lazewatsky

1.0.3 (2014-03-01)
------------------

1.0.2 (2014-02-28)
------------------

1.0.1 (2014-02-27)
------------------
* catkinizing
* Contributors: Dan Lazewatsky