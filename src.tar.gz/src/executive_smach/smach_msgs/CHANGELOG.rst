^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package smach_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.0 (2014-04-17)
------------------
* cleaning up and removing rosbuild support
* merging groovy and hydro
* Add explanations within message definitions
* Contributors: Felix Kolbe, Jonathan Bohren

1.3.1 (2013-07-22)
------------------
* adding changelogs
* Updating maintainer name

* Updating maintainer name
