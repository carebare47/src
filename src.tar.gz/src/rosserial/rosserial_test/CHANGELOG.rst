^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosserial_test
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.4 (2016-09-21)
------------------
* Integration tests for rosserial (`#243 <https://github.com/ros-drivers/rosserial/issues/243>`_)
* Contributors: Mike Purvis
